library(testthat)
library(shinymanager)

test_check("shinymanager")
